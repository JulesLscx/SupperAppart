package Vue;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionAssuranceImmeuble;

import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class FEN_AssuranceImmeuble extends JInternalFrame {
	private JTextField assuranceBien, assuranceJuridique, annee, certificatBien, certificatJuridique;
	private JTable table_AssuranceImmeuble;
	private GestionAssuranceImmeuble controlleur;
	private JComboBox<String> immeuble;

	public FEN_AssuranceImmeuble() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		assuranceBien = new JTextField();
		assuranceBien.setBounds(38, 72, 180, 32);
		getContentPane().add(assuranceBien);
		assuranceBien.setColumns(10);

		assuranceJuridique = new JTextField();
		assuranceJuridique.setBounds(38, 194, 180, 32);
		getContentPane().add(assuranceJuridique);
		assuranceJuridique.setColumns(10);

		annee = new JTextField();
		annee.setBounds(38, 317, 180, 32);
		getContentPane().add(annee);
		annee.setColumns(10);

		certificatBien = new JTextField();
		certificatBien.setBounds(303, 72, 180, 32);
		getContentPane().add(certificatBien);
		certificatBien.setColumns(10);

		certificatJuridique = new JTextField();
		certificatJuridique.setBounds(303, 194, 180, 32);
		getContentPane().add(certificatJuridique);
		certificatJuridique.setColumns(10);

		JLabel lblassuranceBien = new JLabel("Assurance Bien: ");
		lblassuranceBien.setBounds(38, 52, 107, 20);
		getContentPane().add(lblassuranceBien);

		JLabel lblassuranceJuridique = new JLabel("assuranceJuridique: ");
		lblassuranceJuridique.setBounds(38, 174, 107, 20);
		getContentPane().add(lblassuranceJuridique);

		JLabel lblannee = new JLabel("Ann�e: ");
		lblannee.setBounds(38, 297, 80, 20);
		getContentPane().add(lblannee);

		JLabel lblcertificatBien = new JLabel("Certificat bien: ");
		lblcertificatBien.setBounds(303, 52, 80, 20);
		getContentPane().add(lblcertificatBien);

		JLabel lblcertificatJuridique = new JLabel("Certificat juridique: ");
		lblcertificatJuridique.setBounds(303, 174, 113, 20);
		getContentPane().add(lblcertificatJuridique);

		immeuble = new JComboBox<String>();
		immeuble.setBounds(303, 317, 180, 32);
		getContentPane().add(immeuble);

		JButton ajouterIm = new JButton("Ajouter");
		ajouterIm.setBounds(303, 297, 89, 23);
		getContentPane().add(ajouterIm);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_AssuranceImmeuble = new JTable();
		table_AssuranceImmeuble.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
				},
				new String[] {
						"assuranceBien", "assuranceJuridique", "annee", "Immeuble",
				}));
		spFactureExistante.setViewportView(table_AssuranceImmeuble);

		JLabel lblImmeuble = new JLabel("Immeuble: ");
		lblImmeuble.setBounds(403, 297, 80, 20);
		getContentPane().add(lblImmeuble);

		this.controlleur = new GestionAssuranceImmeuble(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);

	}

	public JComboBox<String> getComboImmeuble() {
		return this.immeuble;
	}

	public void setComboImmeuble(JComboBox<String> field) {
		this.immeuble = field;
	}
}
