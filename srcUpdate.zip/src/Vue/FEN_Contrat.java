package Vue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionContrat;

public class FEN_Contrat extends JInternalFrame {
	private JTextField idContrat, charges, duree, priseEffet, datePaiement, periodicite, loyer, dateRevision;
	private JTextField finContrat, montantCaution, paiement, dateEDL;
	private JTable table_Facture;
	private GestionContrat controlleur;

	public FEN_Contrat() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		idContrat = new JTextField();
		idContrat.setBounds(49, 31, 180, 25);
		getContentPane().add(idContrat);
		idContrat.setColumns(10);

		JLabel lblidContrat = new JLabel("Identifiant contrat: ");
		lblidContrat.setBounds(49, 10, 101, 19);
		getContentPane().add(lblidContrat);

		JLabel lbllocataire = new JLabel("Locataire: ");
		lbllocataire.setBounds(148, 348, 101, 19);
		getContentPane().add(lbllocataire);

		JLabel lblcaution = new JLabel("Caution: ");
		lblcaution.setBounds(413, 348, 101, 19);
		getContentPane().add(lblcaution);

		JComboBox locataire = new JComboBox();
		locataire.setBounds(49, 365, 180, 25);
		getContentPane().add(locataire);

		JComboBox caution = new JComboBox();
		caution.setBounds(314, 364, 180, 25);
		getContentPane().add(caution);

		JButton ajouterLo = new JButton("Ajouter");
		ajouterLo.setBounds(49, 346, 89, 20);
		getContentPane().add(ajouterLo);

		JButton ajouterCau = new JButton("Ajouter");
		ajouterCau.setBounds(314, 346, 89, 20);
		getContentPane().add(ajouterCau);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_Facture = new JTable();
		table_Facture.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
				},
				new String[] {
						"nature", "facture", "prix", "numFact", "montIndeductible", "reduction", "ordreCheque",
						"numCheque", "datePaiement", "Entrepreneur", "Logement",
				}));
		spFactureExistante.setViewportView(table_Facture);

		charges = new JTextField();
		charges.setColumns(10);
		charges.setBounds(314, 87, 180, 25);
		getContentPane().add(charges);

		JLabel lblcharges = new JLabel("Charges: ");
		lblcharges.setBounds(314, 66, 101, 19);
		getContentPane().add(lblcharges);

		duree = new JTextField();
		duree.setColumns(10);
		duree.setBounds(49, 87, 180, 25);
		getContentPane().add(duree);

		JLabel lblduree = new JLabel("Dur\u00E9e: ");
		lblduree.setBounds(49, 66, 101, 19);
		getContentPane().add(lblduree);

		priseEffet = new JTextField();
		priseEffet.setColumns(10);
		priseEffet.setBounds(314, 31, 180, 25);
		getContentPane().add(priseEffet);

		JLabel lblpriseEffet = new JLabel("Prise effet: ");
		lblpriseEffet.setBounds(314, 10, 101, 19);
		getContentPane().add(lblpriseEffet);

		datePaiement = new JTextField();
		datePaiement.setColumns(10);
		datePaiement.setBounds(314, 199, 180, 25);
		getContentPane().add(datePaiement);

		JLabel lbldatePaiement = new JLabel("Date Paiement: ");
		lbldatePaiement.setBounds(314, 178, 101, 19);
		getContentPane().add(lbldatePaiement);

		periodicite = new JTextField();
		periodicite.setColumns(10);
		periodicite.setBounds(49, 199, 180, 25);
		getContentPane().add(periodicite);

		JLabel lblperiodicite = new JLabel("P\u00E9riodicit\u00E9: ");
		lblperiodicite.setBounds(49, 178, 101, 19);
		getContentPane().add(lblperiodicite);

		loyer = new JTextField();
		loyer.setColumns(10);
		loyer.setBounds(49, 143, 180, 25);
		getContentPane().add(loyer);

		JLabel lblloyer = new JLabel("Loyer: ");
		lblloyer.setBounds(49, 122, 101, 19);
		getContentPane().add(lblloyer);

		dateRevision = new JTextField();
		dateRevision.setColumns(10);
		dateRevision.setBounds(314, 143, 180, 25);
		getContentPane().add(dateRevision);

		JLabel lbldateRevision = new JLabel("Date r\u00E9vision: ");
		lbldateRevision.setBounds(314, 122, 101, 19);
		getContentPane().add(lbldateRevision);

		finContrat = new JTextField();
		finContrat.setColumns(10);
		finContrat.setBounds(314, 311, 180, 25);
		getContentPane().add(finContrat);

		JLabel lblfinContrat = new JLabel("Fin Contrat:");
		lblfinContrat.setBounds(314, 290, 101, 19);
		getContentPane().add(lblfinContrat);

		montantCaution = new JTextField();
		montantCaution.setColumns(10);
		montantCaution.setBounds(49, 311, 180, 25);
		getContentPane().add(montantCaution);

		JLabel lblmontantCaution = new JLabel("Montant Caution: ");
		lblmontantCaution.setBounds(49, 290, 101, 19);
		getContentPane().add(lblmontantCaution);

		paiement = new JTextField();
		paiement.setColumns(10);
		paiement.setBounds(49, 255, 180, 25);
		getContentPane().add(paiement);

		JLabel lblpaiement = new JLabel("Paiement: ");
		lblpaiement.setBounds(49, 234, 101, 19);
		getContentPane().add(lblpaiement);

		dateEDL = new JTextField();
		dateEDL.setColumns(10);
		dateEDL.setBounds(314, 255, 180, 25);
		getContentPane().add(dateEDL);

		JLabel lbldateEDL = new JLabel("Date EDL: ");
		lbldateEDL.setBounds(314, 234, 101, 19);
		getContentPane().add(lbldateEDL);

		JComboBox logement = new JComboBox();
		logement.setBounds(188, 419, 180, 25);
		getContentPane().add(logement);

		JButton ajouterLog = new JButton("Ajouter");
		ajouterLog.setBounds(188, 400, 89, 20);
		getContentPane().add(ajouterLog);

		JLabel lbllogement = new JLabel("Logements:");
		lbllogement.setBounds(287, 402, 101, 19);
		getContentPane().add(lbllogement);

		this.controlleur = new GestionContrat(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);

	}
}
