package Vue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionFactureTravaux;

public class FEN_Facture_Travaux extends JInternalFrame {
	private JTextField nature, facture, prix, numFact, montIndeductible, reduction, ordreCheque, numCheque,
			datePaiement;
	private JTable table_Facture;
	private GestionFactureTravaux controlleur;

	/**
	 * Launch the application.
	 * public static void main(String[] args) {
	 * EventQueue.invokeLater(new Runnable() {
	 * public void run() {
	 * try {
	 * Facture frame = new Facture();
	 * frame.setVisible(true);
	 * } catch (Exception e) {
	 * e.printStackTrace();
	 * }
	 * }
	 * });
	 * }
	 * 
	 * /**
	 * Create the frame.
	 */
	public FEN_Facture_Travaux() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		nature = new JTextField();
		nature.setBounds(49, 33, 180, 30);
		getContentPane().add(nature);
		nature.setColumns(10);

		prix = new JTextField();
		prix.setBounds(49, 109, 180, 30);
		getContentPane().add(prix);
		prix.setColumns(10);

		numFact = new JTextField();
		numFact.setBounds(49, 187, 180, 30);
		getContentPane().add(numFact);
		numFact.setColumns(10);

		montIndeductible = new JTextField();
		montIndeductible.setBounds(49, 265, 180, 30);
		getContentPane().add(montIndeductible);
		montIndeductible.setColumns(10);

		reduction = new JTextField();
		reduction.setBounds(314, 33, 180, 30);
		getContentPane().add(reduction);
		reduction.setColumns(10);

		ordreCheque = new JTextField();
		ordreCheque.setBounds(314, 109, 180, 30);
		getContentPane().add(ordreCheque);
		ordreCheque.setColumns(10);

		numCheque = new JTextField();
		numCheque.setBounds(314, 265, 180, 30);
		getContentPane().add(numCheque);
		numCheque.setColumns(10);

		datePaiement = new JTextField();
		datePaiement.setBounds(314, 187, 180, 30);
		getContentPane().add(datePaiement);
		datePaiement.setColumns(10);

		facture = new JTextField();
		facture.setBounds(180, 328, 180, 30);
		getContentPane().add(facture);
		facture.setColumns(10);

		JLabel lblNature = new JLabel("Nature: ");
		lblNature.setBounds(49, 12, 101, 19);
		getContentPane().add(lblNature);

		JLabel lblPrix = new JLabel("Prix: ");
		lblPrix.setBounds(49, 88, 101, 19);
		getContentPane().add(lblPrix);

		JLabel lblnumFact = new JLabel("Num�ro facture: ");
		lblnumFact.setBounds(49, 164, 101, 19);
		getContentPane().add(lblnumFact);

		JLabel lblmontIndeductible = new JLabel("Montant ind�ductible: ");
		lblmontIndeductible.setBounds(49, 242, 116, 19);
		getContentPane().add(lblmontIndeductible);

		JLabel lblreduction = new JLabel("R�duction: ");
		lblreduction.setBounds(314, 13, 101, 19);
		getContentPane().add(lblreduction);

		JLabel lblordreCheque = new JLabel("Ordre cheque: ");
		lblordreCheque.setBounds(314, 88, 101, 19);
		getContentPane().add(lblordreCheque);

		JLabel lblnumCheque = new JLabel("Num�ro cheque: ");
		lblnumCheque.setBounds(314, 164, 101, 19);
		getContentPane().add(lblnumCheque);

		JLabel lbldatePaiement = new JLabel("Date paiement: ");
		lbldatePaiement.setBounds(314, 242, 101, 19);
		getContentPane().add(lbldatePaiement);

		JLabel lblfacture = new JLabel("Facture: ");
		lblfacture.setBounds(180, 305, 101, 19);
		getContentPane().add(lblfacture);

		JLabel lbllogement = new JLabel("Logement: ");
		lbllogement.setBounds(148, 385, 101, 19);
		getContentPane().add(lbllogement);

		JLabel lblentrepreneur = new JLabel("Entrepreneur: ");
		lblentrepreneur.setBounds(413, 385, 101, 19);
		getContentPane().add(lblentrepreneur);

		JComboBox logement = new JComboBox();
		logement.setBounds(49, 402, 180, 30);
		getContentPane().add(logement);

		JComboBox entrepreneur = new JComboBox();
		entrepreneur.setBounds(314, 401, 180, 30);
		getContentPane().add(entrepreneur);

		JButton ajouterLo = new JButton("Ajouter");
		ajouterLo.setBounds(49, 383, 89, 23);
		getContentPane().add(ajouterLo);

		JButton ajouterEn = new JButton("Ajouter");
		ajouterEn.setBounds(314, 383, 89, 23);
		getContentPane().add(ajouterEn);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_Facture = new JTable();
		table_Facture.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
				},
				new String[] {
						"nature", "facture", "prix", "numFact", "montIndeductible", "reduction", "ordreCheque",
						"numCheque", "datePaiement", "Entrepreneur", "Logement",
				}));
		spFactureExistante.setViewportView(table_Facture);
		this.controlleur = new GestionFactureTravaux(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);
	}

}
