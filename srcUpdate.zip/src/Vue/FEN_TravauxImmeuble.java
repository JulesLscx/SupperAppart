package Vue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionTravauxImmeuble;

public class FEN_TravauxImmeuble extends JInternalFrame {
	private JTextField nature;
	private JTable table_Facture;
	private JTextField charges;
	private JTextField numFacture;
	private JTextField priseEffet;
	private JTextField datePaiement;
	private JTextField numCheque;
	private JTextField reduction;
	private JTextField dateRevision;
	private JTextField facture;
	private GestionTravauxImmeuble controlleur;

	public FEN_TravauxImmeuble() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		nature = new JTextField();
		nature.setBounds(49, 70, 180, 25);
		getContentPane().add(nature);
		nature.setColumns(10);

		JLabel lblnature = new JLabel("Nature: ");
		lblnature.setBounds(49, 49, 101, 19);
		getContentPane().add(lblnature);

		JLabel lblImmeuble = new JLabel("Immeuble: ");
		lblImmeuble.setBounds(148, 367, 101, 19);
		getContentPane().add(lblImmeuble);

		JLabel lblentrepreneur = new JLabel("Entrepreneur: ");
		lblentrepreneur.setBounds(413, 367, 101, 19);
		getContentPane().add(lblentrepreneur);

		JComboBox immeuble = new JComboBox();
		immeuble.setBounds(49, 384, 180, 30);
		getContentPane().add(immeuble);

		JComboBox entrepreneur = new JComboBox();
		entrepreneur.setBounds(314, 383, 180, 30);
		getContentPane().add(entrepreneur);

		JButton ajouterIm = new JButton("Ajouter");
		ajouterIm.setBounds(49, 365, 89, 23);
		getContentPane().add(ajouterIm);

		JButton ajouterEn = new JButton("Ajouter");
		ajouterEn.setBounds(314, 365, 89, 23);
		getContentPane().add(ajouterEn);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_Facture = new JTable();
		table_Facture.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, null, null, null, },
				},
				new String[] {
						"nature", "facture", "prix", "numFact", "montIndeductible", "reduction", "ordreCheque",
						"numCheque", "datePaiement", "Entrepreneur", "Logement",
				}));
		spFactureExistante.setViewportView(table_Facture);

		charges = new JTextField();
		charges.setColumns(10);
		charges.setBounds(314, 126, 180, 25);
		getContentPane().add(charges);

		JLabel lblmontantIndeductible = new JLabel("Montant Indeductible: ");
		lblmontantIndeductible.setBounds(314, 105, 125, 19);
		getContentPane().add(lblmontantIndeductible);

		numFacture = new JTextField();
		numFacture.setColumns(10);
		numFacture.setBounds(49, 126, 180, 25);
		getContentPane().add(numFacture);

		JLabel lblnumFacture = new JLabel("Num\u00E9ro Facture: ");
		lblnumFacture.setBounds(49, 105, 101, 19);
		getContentPane().add(lblnumFacture);

		priseEffet = new JTextField();
		priseEffet.setColumns(10);
		priseEffet.setBounds(314, 70, 180, 25);
		getContentPane().add(priseEffet);

		JLabel lblprix = new JLabel("Prix: ");
		lblprix.setBounds(314, 49, 101, 19);
		getContentPane().add(lblprix);

		datePaiement = new JTextField();
		datePaiement.setColumns(10);
		datePaiement.setBounds(314, 238, 180, 25);
		getContentPane().add(datePaiement);

		JLabel lbldatePaiement = new JLabel("Date Paiement: ");
		lbldatePaiement.setBounds(314, 217, 101, 19);
		getContentPane().add(lbldatePaiement);

		numCheque = new JTextField();
		numCheque.setColumns(10);
		numCheque.setBounds(49, 238, 180, 25);
		getContentPane().add(numCheque);

		JLabel lblnumCheque = new JLabel("Num\u00E9ro Ch\u00E8que: ");
		lblnumCheque.setBounds(49, 217, 101, 19);
		getContentPane().add(lblnumCheque);

		reduction = new JTextField();
		reduction.setColumns(10);
		reduction.setBounds(49, 182, 180, 25);
		getContentPane().add(reduction);

		JLabel lblreduction = new JLabel("R\u00E9duction: ");
		lblreduction.setBounds(49, 161, 101, 19);
		getContentPane().add(lblreduction);

		dateRevision = new JTextField();
		dateRevision.setColumns(10);
		dateRevision.setBounds(314, 182, 180, 25);
		getContentPane().add(dateRevision);

		JLabel lblordreCheque = new JLabel("Ordre ch\u00E8que: ");
		lblordreCheque.setBounds(314, 161, 101, 19);
		getContentPane().add(lblordreCheque);

		facture = new JTextField();
		facture.setColumns(10);
		facture.setBounds(184, 294, 180, 25);
		getContentPane().add(facture);

		JLabel lblfacture = new JLabel("Facture:");
		lblfacture.setBounds(184, 273, 101, 19);
		getContentPane().add(lblfacture);
		this.controlleur = new GestionTravauxImmeuble(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);
	}

}
