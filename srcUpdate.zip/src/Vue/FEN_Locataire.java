package Vue;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionLocataire;

public class FEN_Locataire extends JInternalFrame {
	private JTextField nLocataire, nom, prenom, email, telephone, genre;
	private JTable table_Locataire;

	public JTable getTable_Locataire() {
		return table_Locataire;
	}

	private GestionLocataire controlleur;
	private JCheckBox courants;

	public FEN_Locataire() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		nLocataire = new JTextField();
		nLocataire.setBounds(37, 42, 180, 32);
		getContentPane().add(nLocataire);
		nLocataire.setColumns(10);

		nom = new JTextField();
		nom.setBounds(37, 142, 180, 32);
		getContentPane().add(nom);
		nom.setColumns(10);

		prenom = new JTextField();
		prenom.setBounds(37, 247, 180, 32);
		getContentPane().add(prenom);
		prenom.setColumns(10);

		email = new JTextField();
		email.setBounds(302, 42, 180, 32);
		getContentPane().add(email);
		email.setColumns(10);

		telephone = new JTextField();
		telephone.setBounds(302, 142, 180, 32);
		getContentPane().add(telephone);
		telephone.setColumns(10);

		genre = new JTextField();
		genre.setBounds(302, 247, 180, 32);
		getContentPane().add(genre);
		genre.setColumns(10);

		JLabel lblnLocataire = new JLabel("Numero Locataire: ");
		lblnLocataire.setBounds(37, 22, 107, 20);
		getContentPane().add(lblnLocataire);

		JLabel lblnom = new JLabel("Nom: ");
		lblnom.setBounds(37, 122, 107, 20);
		getContentPane().add(lblnom);

		JLabel lblprenom = new JLabel("Prenom: ");
		lblprenom.setBounds(37, 227, 80, 20);
		getContentPane().add(lblprenom);

		JLabel lblemail = new JLabel("Email: ");
		lblemail.setBounds(302, 22, 80, 20);
		getContentPane().add(lblemail);

		JLabel lbtelephone = new JLabel("T\u00E9l\u00E9phone: ");
		lbtelephone.setBounds(302, 122, 113, 20);
		getContentPane().add(lbtelephone);

		JLabel lblgenre = new JLabel("Genre:");
		lblgenre.setBounds(302, 227, 80, 20);
		getContentPane().add(lblgenre);

		JComboBox Contrat = new JComboBox();
		Contrat.setBounds(37, 353, 180, 32);
		getContentPane().add(Contrat);

		JComboBox logement = new JComboBox();
		logement.setBounds(302, 353, 180, 32);
		getContentPane().add(logement);

		JButton ajouterCo = new JButton("Ajouter");
		ajouterCo.setBounds(37, 333, 89, 23);
		getContentPane().add(ajouterCo);

		JButton ajouterLo = new JButton("Ajouter");
		ajouterLo.setBounds(302, 333, 89, 23);
		getContentPane().add(ajouterLo);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		courants = new JCheckBox("Seulement les locataires actuels");
		courants.setBounds(398, 310, 89, 23);
		getContentPane().add(courants);

		JButton btn_charger = new JButton("Charger");
		btn_charger.setBounds(398, 409, 89, 23);
		getContentPane().add(btn_charger);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_Locataire = new JTable();
		table_Locataire.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
				},
				new String[] { "nLocataire", "nom", "prenom",
						"email", "telephone", "genre" }));
		spFactureExistante.setViewportView(table_Locataire);

		JLabel lblcontrat = new JLabel("Contrat: ");
		lblcontrat.setBounds(137, 333, 80, 20);
		getContentPane().add(lblcontrat);

		JLabel lbllogement = new JLabel("Logement: ");
		lbllogement.setBounds(401, 333, 80, 20);
		getContentPane().add(lbllogement);

		this.controlleur = new GestionLocataire(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);
		btn_charger.addActionListener(controlleur);
	}

	public boolean isCheck() {
		return this.courants.isSelected();
	}

}
