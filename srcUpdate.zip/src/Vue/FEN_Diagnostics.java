package Vue;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionDiagnostics;

public class FEN_Diagnostics extends JInternalFrame {
	private JTextField Reference, DateD, Diagnostic;
	private JTable table_Diagnostic;
	private GestionDiagnostics controlleur;

	public FEN_Diagnostics() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		Reference = new JTextField();
		Reference.setBounds(45, 112, 180, 32);
		getContentPane().add(Reference);
		Reference.setColumns(10);

		DateD = new JTextField();
		DateD.setBounds(45, 210, 180, 32);
		getContentPane().add(DateD);
		DateD.setColumns(10);

		Diagnostic = new JTextField();
		Diagnostic.setBounds(45, 299, 180, 32);
		getContentPane().add(Diagnostic);
		Diagnostic.setColumns(10);

		JLabel lblReference = new JLabel("R�f�rence: ");
		lblReference.setBounds(45, 92, 80, 20);
		getContentPane().add(lblReference);

		JLabel lblDateD = new JLabel("Date Diagnostic: ");
		lblDateD.setBounds(45, 190, 80, 20);
		getContentPane().add(lblDateD);

		JLabel lblDiagnostic = new JLabel("Diagnostic: ");
		lblDiagnostic.setBounds(45, 280, 80, 20);
		getContentPane().add(lblDiagnostic);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_Diagnostic = new JTable();
		table_Diagnostic.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
						{ null, null, null, null, null, },
				},
				new String[] {
						"R�f�rence", "Date Diagnostic", "Diagnostic", "Type", "Logement", }));
		spFactureExistante.setViewportView(table_Diagnostic);

		JComboBox logement = new JComboBox();
		logement.setBounds(315, 111, 180, 32);
		getContentPane().add(logement);

		JButton ajouterLo = new JButton("Ajouter");
		ajouterLo.setBounds(315, 92, 80, 20);
		getContentPane().add(ajouterLo);

		JComboBox TypeD = new JComboBox();
		TypeD.setBounds(315, 299, 180, 32);
		getContentPane().add(TypeD);

		JButton ajouterTD = new JButton("Ajouter");
		ajouterTD.setBounds(315, 280, 80, 20);
		getContentPane().add(ajouterTD);

		JLabel lbllogement = new JLabel("Logement: ");
		lbllogement.setBounds(399, 92, 80, 20);
		getContentPane().add(lbllogement);

		JLabel lblTypeD = new JLabel("Type diagnostic: ");
		lblTypeD.setBounds(399, 280, 80, 20);
		getContentPane().add(lblTypeD);

		this.controlleur = new GestionDiagnostics(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);

	}
}
