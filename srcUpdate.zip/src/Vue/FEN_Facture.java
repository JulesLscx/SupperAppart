package Vue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionFacture;

public class FEN_Facture extends JInternalFrame {
	private JTextField numFact, monFact, prixFact, dateFact, coutFact, prixConsFact;
	private JTable table_Facture;
	private JTextField total;
	private GestionFacture controlleur;

	public FEN_Facture() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		numFact = new JTextField();
		numFact.setBounds(37, 42, 180, 32);
		getContentPane().add(numFact);
		numFact.setColumns(10);

		monFact = new JTextField();
		monFact.setBounds(37, 119, 180, 32);
		getContentPane().add(monFact);
		monFact.setColumns(10);

		prixFact = new JTextField();
		prixFact.setBounds(37, 201, 180, 32);
		getContentPane().add(prixFact);
		prixFact.setColumns(10);

		dateFact = new JTextField();
		dateFact.setBounds(302, 42, 180, 32);
		getContentPane().add(dateFact);
		dateFact.setColumns(10);

		coutFact = new JTextField();
		coutFact.setBounds(302, 119, 180, 32);
		getContentPane().add(coutFact);
		coutFact.setColumns(10);

		prixConsFact = new JTextField();
		prixConsFact.setBounds(302, 201, 180, 32);
		getContentPane().add(prixConsFact);
		prixConsFact.setColumns(10);

		JLabel lblNumFact = new JLabel("Numero Facture: ");
		lblNumFact.setBounds(37, 22, 107, 20);
		getContentPane().add(lblNumFact);

		JLabel lblMontFact = new JLabel("Montant Facture: ");
		lblMontFact.setBounds(37, 99, 107, 20);
		getContentPane().add(lblMontFact);

		JLabel lblPrixUniteReleve = new JLabel("Prix unite releve: ");
		lblPrixUniteReleve.setBounds(37, 181, 80, 20);
		getContentPane().add(lblPrixUniteReleve);

		JLabel lblDateFacture = new JLabel("Date Facture: ");
		lblDateFacture.setBounds(302, 22, 80, 20);
		getContentPane().add(lblDateFacture);

		JLabel lblCoutFixeFacture = new JLabel("Cout fixe facture: ");
		lblCoutFixeFacture.setBounds(302, 99, 113, 20);
		getContentPane().add(lblCoutFixeFacture);

		JLabel lblPrixUniteContaste = new JLabel("Prix unite constate: ");
		lblPrixUniteContaste.setBounds(302, 181, 80, 20);
		getContentPane().add(lblPrixUniteContaste);

		JComboBox typeFact = new JComboBox();
		typeFact.setBounds(37, 353, 180, 32);
		getContentPane().add(typeFact);

		JComboBox immConcerne = new JComboBox();
		immConcerne.setBounds(302, 353, 180, 32);
		getContentPane().add(immConcerne);

		JButton ajouterTF = new JButton("Ajouter");
		ajouterTF.setBounds(37, 333, 89, 23);
		getContentPane().add(ajouterTF);

		JButton ajouterIC = new JButton("Ajouter");
		ajouterIC.setBounds(302, 333, 89, 23);
		getContentPane().add(ajouterIC);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_Facture = new JTable();
		table_Facture.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, },
				},
				new String[] {
						"NFacture", "Montant", "Prix", "Date", "CoutFixe", "PrixConstate", "Total",
				}));
		spFactureExistante.setViewportView(table_Facture);

		JLabel lblTypeF = new JLabel("Type Facture: ");
		lblTypeF.setBounds(137, 333, 80, 20);
		getContentPane().add(lblTypeF);

		JLabel lblImmeuble = new JLabel("Immeuble: ");
		lblImmeuble.setBounds(401, 333, 80, 20);
		getContentPane().add(lblImmeuble);

		total = new JTextField();
		total.setColumns(10);
		total.setBounds(177, 275, 180, 32);
		getContentPane().add(total);

		JLabel lblTotal = new JLabel("Total: ");
		lblTotal.setBounds(177, 255, 80, 20);
		getContentPane().add(lblTotal);

		this.controlleur = new GestionFacture(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);

	}

}
