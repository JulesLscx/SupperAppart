package Vue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionLogement;

public class FEN_Logement extends JInternalFrame {
	private JTextField numero, typeHab, surface, nbPiece;
	private JTable table_TypeFacture;
	private GestionLogement controlleur;

	public FEN_Logement() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		numero = new JTextField();
		numero.setBounds(30, 92, 180, 32);
		getContentPane().add(numero);
		numero.setColumns(10);

		typeHab = new JTextField();
		typeHab.setBounds(300, 92, 180, 32);
		getContentPane().add(typeHab);
		typeHab.setColumns(10);

		surface = new JTextField();
		surface.setBounds(30, 223, 180, 32);
		getContentPane().add(surface);
		surface.setColumns(10);

		nbPiece = new JTextField();
		nbPiece.setBounds(300, 223, 180, 32);
		getContentPane().add(nbPiece);
		nbPiece.setColumns(10);

		JLabel lblnumero = new JLabel("Num�ro: ");
		lblnumero.setBounds(30, 72, 80, 20);
		getContentPane().add(lblnumero);

		JLabel lblTypeHab = new JLabel("Type Habitation: ");
		lblTypeHab.setBounds(300, 72, 80, 20);
		getContentPane().add(lblTypeHab);

		JLabel lblSurface = new JLabel("Surface: ");
		lblSurface.setBounds(30, 204, 80, 20);
		getContentPane().add(lblSurface);

		JLabel lblnbPiece = new JLabel("nbPiece: ");
		lblnbPiece.setBounds(300, 204, 80, 20);
		getContentPane().add(lblnbPiece);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_TypeFacture = new JTable();
		table_TypeFacture.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },

				},
				new String[] {
						"Num�ro", "Type Habitation", "Locataire", "Surface", "nbPiece", "Immeuble",
				}));
		spFactureExistante.setViewportView(table_TypeFacture);

		JComboBox immeuble = new JComboBox();
		immeuble.setBounds(30, 337, 180, 32);
		getContentPane().add(immeuble);

		JButton ajouterIm = new JButton("Ajouter");
		ajouterIm.setBounds(30, 318, 80, 20);
		getContentPane().add(ajouterIm);

		JLabel lblimmeuble = new JLabel("Immeuble: ");
		lblimmeuble.setBounds(114, 318, 80, 20);
		getContentPane().add(lblimmeuble);

		JComboBox locataire = new JComboBox();
		locataire.setBounds(300, 337, 180, 32);
		getContentPane().add(locataire);

		JButton ajouterLo = new JButton("Ajouter");
		ajouterLo.setBounds(300, 318, 80, 20);
		getContentPane().add(ajouterLo);

		JLabel lbllocataire = new JLabel("Locataire: ");
		lbllocataire.setBounds(384, 318, 80, 20);
		getContentPane().add(lbllocataire);

		this.controlleur = new GestionLogement(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);
	}
}
