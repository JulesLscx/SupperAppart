package Vue;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionImmeuble;

import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FEN_Immeuble extends JInternalFrame {

	private JTextField Adresse, Pde_Constr, num_bat, CP, ville, copro, Access_Com;
	private JTable table_Facture;
	private GestionImmeuble controlleur;

	public FEN_Immeuble() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		Adresse = new JTextField();
		Adresse.setBounds(37, 42, 180, 32);
		getContentPane().add(Adresse);
		Adresse.setColumns(10);

		Pde_Constr = new JTextField();
		Pde_Constr.setBounds(37, 136, 180, 32);
		getContentPane().add(Pde_Constr);
		Pde_Constr.setColumns(10);

		num_bat = new JTextField();
		num_bat.setBounds(37, 230, 180, 32);
		getContentPane().add(num_bat);
		num_bat.setColumns(10);

		CP = new JTextField();
		CP.setBounds(302, 42, 180, 32);
		getContentPane().add(CP);
		CP.setColumns(10);

		ville = new JTextField();
		ville.setBounds(302, 136, 180, 32);
		getContentPane().add(ville);
		ville.setColumns(10);

		copro = new JTextField();
		copro.setBounds(302, 230, 180, 32);
		getContentPane().add(copro);
		copro.setColumns(10);

		JLabel lblAdresse = new JLabel("Adresse: ");
		lblAdresse.setBounds(37, 22, 80, 20);
		getContentPane().add(lblAdresse);

		JLabel lblPde_Constr = new JLabel("P�riode de construction: ");
		lblPde_Constr.setBounds(37, 116, 80, 20);
		getContentPane().add(lblPde_Constr);

		JLabel lblnum_bat = new JLabel("Num�ro batiment: ");
		lblnum_bat.setBounds(37, 210, 80, 20);
		getContentPane().add(lblnum_bat);

		JLabel lblCP = new JLabel("Code Postal: ");
		lblCP.setBounds(302, 22, 80, 20);
		getContentPane().add(lblCP);

		JLabel lblville = new JLabel("Ville: ");
		lblville.setBounds(302, 116, 80, 20);
		getContentPane().add(lblville);

		JLabel lblcopro = new JLabel("Copropri�taire: ");
		lblcopro.setBounds(302, 210, 80, 20);
		getContentPane().add(lblcopro);

		Access_Com = new JTextField();
		Access_Com.setBounds(37, 321, 180, 32);
		getContentPane().add(Access_Com);
		Adresse.setColumns(10);

		JLabel lblAccess_Com = new JLabel("??????");
		lblAccess_Com.setBounds(37, 301, 80, 20);
		getContentPane().add(lblAccess_Com);

		JLabel ajouterIC = new JLabel("Identifiant Immeuble");
		ajouterIC.setBounds(302, 301, 80, 20);
		getContentPane().add(ajouterIC);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_Facture = new JTable();
		table_Facture.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
						{ null, null, null, null, null, null, null, null, },
				},
				new String[] {
						"Identifiant", "Adresse", "P�riode", "Copropri�taire", "Num�ro", "CP", "Ville", "????????",
				}));
		spFactureExistante.setViewportView(table_Facture);

		JSpinner IdImmeuble = new JSpinner();
		IdImmeuble.setBounds(302, 321, 180, 32);
		getContentPane().add(IdImmeuble);

		this.controlleur = new GestionImmeuble(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);
	}

}
