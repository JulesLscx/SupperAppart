package Vue;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionPaiements;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FEN_Paiements extends JInternalFrame {
	private JTextField idPaiements, montant, moyenPaiements, datePaiments;
	private JTable table_TypeFacture;
	private GestionPaiements controlleur;

	/**
	 * Launch the application.
	 * public static void main(String[] args) {
	 * EventQueue.invokeLater(new Runnable() {
	 * public void run() {
	 * try {
	 * Facture frame = new Facture();
	 * frame.setVisible(true);
	 * } catch (Exception e) {
	 * e.printStackTrace();
	 * }
	 * }
	 * });
	 * }
	 * 
	 * /**
	 * Create the frame.
	 */
	public FEN_Paiements() {
		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		idPaiements = new JTextField();
		idPaiements.setBounds(30, 92, 180, 32);
		getContentPane().add(idPaiements);
		idPaiements.setColumns(10);

		montant = new JTextField();
		montant.setBounds(300, 92, 180, 32);
		getContentPane().add(montant);
		montant.setColumns(10);

		moyenPaiements = new JTextField();
		moyenPaiements.setBounds(30, 223, 180, 32);
		getContentPane().add(moyenPaiements);
		moyenPaiements.setColumns(10);

		datePaiments = new JTextField();
		datePaiments.setBounds(300, 223, 180, 32);
		getContentPane().add(datePaiments);
		datePaiments.setColumns(10);

		JLabel lblidPaiements = new JLabel("Id Paiements: ");
		lblidPaiements.setBounds(30, 72, 80, 20);
		getContentPane().add(lblidPaiements);

		JLabel lblmontant = new JLabel("Montant: ");
		lblmontant.setBounds(300, 72, 80, 20);
		getContentPane().add(lblmontant);

		JLabel lblmoyenPaiements = new JLabel("Moyen Paiements: ");
		lblmoyenPaiements.setBounds(30, 204, 93, 20);
		getContentPane().add(lblmoyenPaiements);

		JLabel lbldatePaiement = new JLabel("Date Paiements: ");
		lbldatePaiement.setBounds(300, 204, 80, 20);
		getContentPane().add(lbldatePaiement);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_TypeFacture = new JTable();
		table_TypeFacture.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },
						{ null, null, null, null, null, null, },

				},
				new String[] {
						"Num�ro", "Type Habitation", "Locataire", "Surface", "nbPiece", "Immeuble",
				}));
		spFactureExistante.setViewportView(table_TypeFacture);

		JComboBox contrat = new JComboBox();
		contrat.setBounds(175, 336, 180, 32);
		getContentPane().add(contrat);

		JButton ajouterCo = new JButton("Ajouter");
		ajouterCo.setBounds(175, 317, 80, 20);
		getContentPane().add(ajouterCo);

		JLabel lblContrat = new JLabel("Contrat: ");
		lblContrat.setBounds(259, 317, 80, 20);
		getContentPane().add(lblContrat);

		this.controlleur = new GestionPaiements(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);

	}

}
