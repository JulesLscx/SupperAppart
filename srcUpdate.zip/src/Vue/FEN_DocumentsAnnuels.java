package Vue;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Controlleur.GestionDocumentsAnnuels;

public class FEN_DocumentsAnnuels extends JInternalFrame {
	private JTextField annee, ramonage;
	private JTable table_DocumentsAnnuels;
	private GestionDocumentsAnnuels controlleur;

	public FEN_DocumentsAnnuels() {

		setBounds(0, 0, 880, 473);
		getContentPane().setLayout(null);

		annee = new JTextField();
		annee.setBounds(167, 66, 180, 32);
		getContentPane().add(annee);
		annee.setColumns(10);

		JTextField certificat = new JTextField();
		certificat.setBounds(167, 160, 180, 32);
		getContentPane().add(certificat);
		certificat.setColumns(10);

		ramonage = new JTextField();
		ramonage.setBounds(167, 254, 180, 32);
		getContentPane().add(ramonage);
		ramonage.setColumns(10);

		JLabel lblannee = new JLabel("Ann\u00E9e:");
		lblannee.setBounds(167, 46, 80, 20);
		getContentPane().add(lblannee);

		JLabel lblcertificat = new JLabel("Certificat: ");
		lblcertificat.setBounds(167, 140, 80, 20);
		getContentPane().add(lblcertificat);

		JLabel lblramonage = new JLabel("Ramonage: ");
		lblramonage.setBounds(167, 234, 80, 20);
		getContentPane().add(lblramonage);

		JButton valider = new JButton("Valider");
		valider.setBounds(567, 409, 89, 23);
		getContentPane().add(valider);

		JButton annuler = new JButton("Annuler");
		annuler.setBounds(698, 409, 89, 23);
		getContentPane().add(annuler);

		JButton ajouterLo = new JButton("Ajouter");
		ajouterLo.setBounds(167, 324, 89, 23);
		getContentPane().add(ajouterLo);

		JComboBox locataire = new JComboBox();
		locataire.setBounds(167, 344, 180, 32);
		getContentPane().add(locataire);

		JLabel lbllocataire = new JLabel("Locataire: ");
		lbllocataire.setBounds(267, 324, 80, 20);
		getContentPane().add(lbllocataire);

		JScrollPane spFactureExistante = new JScrollPane();
		spFactureExistante.setEnabled(false);
		spFactureExistante.setBounds(514, 31, 340, 358);
		getContentPane().add(spFactureExistante);

		table_DocumentsAnnuels = new JTable();
		table_DocumentsAnnuels.setModel(new DefaultTableModel(
				new Object[][] {
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
						{ null, null, null, null, },
				},
				new String[] {
						"Ann�e", "Certificat", "Ramonage", "Locataire",
				}));
		this.controlleur = new GestionDocumentsAnnuels(this);
		valider.addActionListener(controlleur);
		annuler.addActionListener(controlleur);
		spFactureExistante.setViewportView(table_DocumentsAnnuels);

	}

}
