package Controlleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;

import Vue.FEN_Accueil;
import Vue.FEN_AssuranceImmeuble;

public class GestionAssuranceImmeuble implements ActionListener {
	private FEN_AssuranceImmeuble ai;

	public GestionAssuranceImmeuble(FEN_AssuranceImmeuble ai) {
		this.ai = ai;
		fillComboImmeuble();
	}

	private void fillComboImmeuble() {
		try {
			Connection co = CictOracleDataSource.getLaConnection();
			PreparedStatement st = co.prepareStatement("select id_immeuble  from immeuble");
			ResultSet rs = st.executeQuery();
			JComboBox<String> tmp = this.ai.getComboImmeuble();
			while (rs.next()) {
				tmp.addItem(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton item = (JButton) e.getSource();
		switch (item.getText()) {
			case "Annuler":
				((FEN_Accueil) this.ai.getTopLevelAncestor()).switchOuverte();
				this.ai.dispose();
				break;
		}
	}
}
